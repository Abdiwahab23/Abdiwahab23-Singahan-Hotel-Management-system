<style>
    .main-sidebar{
      width: 200px; /* Set the width of the sidebar */
      background-color: #4da6ff; /* Set the background color of the sidebar */
      padding: 20px; /* Add some padding for content */
      display: flex; /* Use flexbox for layout */
      flex-direction: column;
      margin-top:3px;
 /* Align items vertically */
    }
    
    .profile-usertitle-status {
      color: blue; /* Set the text color */
      font-weight: bold; /* Set the font weight */
      margin-bottom: 10px; /* Add some margin to the bottom */
    }
    .profile-userpic img {
  width: 100px; /* Set the width of the image */
  height: 100px; /* Set the height of the image */
  object-fit: cover; /* Maintain aspect ratio and cover the container */
  border-radius: 50%;
  margin-left:30px; /* Add rounded corners for a circular effect */
}
    .img-responsive{
        width:100px;
        border:solid;
        border-color:#4da6ff;
    }

    .indicator.label-success {
      background-color: #5cb85c; /* Set the background color for success status */
      color: #fff; /* Set the text color for success status */
      padding: 5px 10px; /* Add padding for better visual appearance */
      border-radius: 5px; /* Add rounded corners */
    }

    .nav.menu li {
      list-style-type: none; /* Remove list item bullet points */
      margin-bottom: 10px; /* Add margin between menu items */
    }

    .nav.menu li a {
      display: flex; /* Make the anchor tag a block element to take full width */
      padding: 10px; /* Add padding for better visual appearance */
      text-decoration: none; /* Remove underline */
      color: #333; /* Set the text color */
      background-color: #eee; /* Set the background color for menu items */
      border-radius: 5px;
      font-size:15px; /* Add rounded corners */
    }

    .nav.menu li.active a {
      background-color: #007bff; /* Set a different background color for active menu item */
      color: #fff; /* Set the text color for active menu item */
    }
</style>



<div id="sidebar-collapse" class="main-sidebar">
    <div class="profile-sidebar">
        <div class="profile-userpic">
            <img src="img/usr.png" class="img-responsive" alt="">
        </div>
        <div class="profile-usertitle">
        <?php
// Assuming $user is the array containing user details

// Check if the "name" key exists before trying to access it
$userName = isset($user['name']) ? $user['name'] : "";
?>

<!-- Your existing code continues here -->

<div class="user-details">
    <p>Welcome, <?php echo $userName; ?></p>
</div>

<!-- Your existing code continues here -->

            <div class="profile-usertitle-status"><span class="indicator label-success"></span>Manager</div>
        </div>
        <div class="clear"></div>
    </div>
    <div class="divider"></div>
    <ul class="nav menu">
    <?php 
        if (isset($_GET['dashboard'])){ ?>
            <li class="active">
                <a href="index.php?dashboard"><em class="fa fa-dashboard">&nbsp;</em>
                    Dashboard
                </a>
            </li>
        <?php } else{?>
            <li>
                <a href="index.php?dashboard"><em class="fa fa-dashboard">&nbsp;</em>
                Dashboard
                </a>
            </li>
        <?php }
        if (isset($_GET['Adduser'])){ ?>
            <li class="active">
                <a href="Adduser.php?dashboard"><em class="fa fa-user">&nbsp;</em>
                    Add User
                </a>
            </li>
        <?php } else{?>
            <li>
                <a href="Adduser.php?dashboard"><em class="fa fa-user">&nbsp;</em>
                Add User
                </a>
            </li>
        <?php }
        if (isset($_GET['reservation'])){ ?>
            <li class="active">
            <a href="index.php?reservation"><em class="fa fa-calendar">&nbsp;</em>
                    Reservation
                </a>
            </li>
        <?php } else{?>
            <li>
            <a href="index.php?reservation"><em class="fa fa-calendar">&nbsp;</em>
                    Reservation
                </a>
            </li>
        <?php }
        if (isset($_GET['room_mang'])){ ?>
            <li class="active">
                <a href="index.php?room_mang"><em class="fa fa-bed">&nbsp;</em>
                    Manage Rooms
                </a>
            </li>
        <?php } else{?>
            <li>
            <a href="index.php?room_mang"><em class="fa fa-bed">&nbsp;</em>
                    Manage Rooms
                </a>
            </li>
        <?php }
        if (isset($_GET['staff_mang'])){ ?>
            <li class="active">
                <a href="index.php?staff_mang"><em class="fa fa-users">&nbsp;</em>
                    Staff Section
                </a>
            </li>
        <?php } else{?>
            <li>
                <a href="index.php?staff_mang"><em class="fa fa-users">&nbsp;</em>
                    Staff Section
                </a>
            </li>
        <?php }
        if (isset($_GET['billing'])){ ?>
            <li class="active">
                <a href="index.php?billing"><em class="fa fa-money">&nbsp;</em>
                   Billing
                </a>
            </li>
        <?php } else{?>
            <li>
                <a href="index.php?billing"><em class="fa fa-money">&nbsp;</em>
                   Billing
                </a>
            </li>
        <?php }
        ?>

        
    </ul>
</div><!--/.sidebar-->