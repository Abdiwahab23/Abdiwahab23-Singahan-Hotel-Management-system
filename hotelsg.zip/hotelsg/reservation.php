<?php
    
    require 'db.php'; // Assuming your database connection file is named 'db.php'
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Booking Data</title>
    <link href="css/reservatio.css" rel="stylesheet">
    <style>
        body{
     margin:0;
     padding:0;
    }

.row{
    margin-left: 200px;
    margin-top:-540px;
}
    </style>
</head>

<body>


    

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4>Booking Data
                        <a href="Addreservation.php" class="btn btn-primary float-end">Add Booking</a>
                    </h4>
                </div>
                <div class="card-body">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Guest Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Address</th>
                                <th>Reservation ID</th>
                                <th>Check-in Date</th>
                                <th>Check-out Date</th>
                                <th>Room Number</th>
                                <th>Adults</th>
                                <th>Children</th>
                                <th>Payment ID</th>
                                <th>Total Amount</th>
                                <th>Payment Method</th>
                                <th>Payment Status</th>
                                <th>Date Paid</th>
                                <th>Action</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php
                            $bookingQuery = "SELECT gd.FirstName, gd.LastName, gd.Email, gd.Phone, gd.Address,
                                            rd.ReservationID, rd.CheckInDate, rd.CheckOutDate, rd.RoomNumber, rd.NumberOfAdults, rd.NumberOfChildren,
                                            pd.PaymentID, pd.TotalAmount, pd.PaymentMethod, pd.PaymentStatus, pd.DatePaid
                                            FROM guestdetails gd
                                            JOIN reservationdetails rd ON gd.GuestID = rd.GuestID
                                            JOIN paymentdetails pd ON rd.ReservationID = pd.ReservationID";

                            $bookingResult = mysqli_query($connection, $bookingQuery);

                            if (mysqli_num_rows($bookingResult) > 0) {
                                foreach ($bookingResult as $row) {
                                    ?>
                                    <tr>
                                        <td><?= $row['ReservationID']; ?></td>
                                        <td><?= $row['FirstName'] . ' ' . $row['LastName']; ?></td>
                                        <td><?= $row['Email']; ?></td>
                                        <td><?= $row['Phone']; ?></td>
                                        <td><?= $row['Address']; ?></td>
                                        <td><?= $row['ReservationID']; ?></td>
                                        <td><?= date('M j, Y', strtotime($row['CheckInDate'])); ?></td>
                                        <td><?= date('M j, Y', strtotime($row['CheckOutDate'])); ?></td>
                                        <td><?= $row['RoomNumber']; ?></td>
                                        <td><?= $row['NumberOfAdults']; ?></td>
                                        <td><?= $row['NumberOfChildren']; ?></td>
                                        <td><?= $row['PaymentID']; ?></td>
                                        <td><?= $row['TotalAmount']; ?></td>
                                        <td><?= $row['PaymentMethod']; ?></td>
                                        <td><?= $row['PaymentStatus']; ?></td>
                                        <td><?= date('M j, Y', strtotime($row['DatePaid'])); ?></td>
                                        <td>
                                            <a href="updatereservation.php?ReservationID=<?= $row['ReservationID']; ?>" class="btn btn-primary btn-sm">Update</a>
                                            <a href="deletereservation.php?ReservationID=<?= $row['ReservationID']; ?>" class="btn btn-danger btn-sm">Delete</a>
                                            <form action="deletereservation.php" method="POST" class="d-inline">
                                                <input type="hidden" name="ReservationID" value="<?= $row['ReservationID']; ?>">
                                                
                                            </form>
                                        </td>
                                    </tr>
                                    <?php
                                }
                            } else {
                                echo "<tr><td colspan='18'>No booking data available</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
