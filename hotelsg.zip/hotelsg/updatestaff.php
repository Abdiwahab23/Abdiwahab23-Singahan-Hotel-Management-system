<a href="index.php?staff_mang" class="btn btn-primary">Back to View</a>
<?php
require 'db.php'; // Assuming your database connection file is named 'db.php'

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Fetch data from the form for employee details
    $employeeID = $_POST['employeeID'];
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $positionType = $_POST['positionType'];
    $nationalID = $_POST['nationalID'];
    $address = $_POST['address'];

    // Update data in employeedetails table
    $updateEmployeeQuery = "UPDATE employeedetails 
                            SET FirstName='$firstName', LastName='$lastName', Email='$email', 
                                Phone='$phone', PositionType='$positionType', 
                                NationalID='$nationalID', Address='$address'
                            WHERE EmployeeID = $employeeID";

    if (mysqli_query($connection, $updateEmployeeQuery)) {
        // Fetch data from the form for shift details
        $shiftID = $_POST['shiftID'];
        $shiftStartTime = $_POST['shiftStartTime'];
        $shiftEndTime = $_POST['shiftEndTime'];

        // Update data in employeeshift table
        $updateShiftQuery = "UPDATE employeeshift 
                             SET ShiftStartTime='$shiftStartTime', ShiftEndTime='$shiftEndTime'
                             WHERE EmployeeID = $employeeID";

        if (mysqli_query($connection, $updateShiftQuery)) {
            // Redirect to staff_mang.php with a success message
            header("Location: index.php?staff_mang");
            exit();
        } else {
            // Redirect to staff_mang.php with an error message
            header("Location: index.php?staff_mang?error=Error updating shift: " . mysqli_error($connection));
            exit();
        }
    } else {
        // Redirect to staff_mang.php with an error message
        header("Location: index.php?staff_mang?error=Error updating employee: " . mysqli_error($connection));
        exit();
    }
} elseif ($_SERVER["REQUEST_METHOD"] == "GET") {
    // Check if the EmployeeID is set in the URL
    if (isset($_GET['EmployeeID'])) {
        $employeeID = $_GET['EmployeeID'];

        // Fetch existing data from both tables
        $employeeQuery = "SELECT * FROM employeedetails WHERE EmployeeID = $employeeID";
        $shiftQuery = "SELECT * FROM employeeshift WHERE EmployeeID = $employeeID";

        $employeeResult = mysqli_query($connection, $employeeQuery);
        $shiftResult = mysqli_query($connection, $shiftQuery);

        if (mysqli_num_rows($employeeResult) > 0 && mysqli_num_rows($shiftResult) > 0) {
            $employee = mysqli_fetch_assoc($employeeResult);
            $shift = mysqli_fetch_assoc($shiftResult);
        } else {
            // Redirect to staff_mang.php with an error message if no data found
            header("Location: index.php?staff_mang?error=Employee not found");
            exit();
        }
    } else {
        // Redirect to staff_mang.php with an error message if EmployeeID is not set
        header("Location:  index.php?staff_mang?error=EmployeeID not specified");
        exit();
    }
} else {
    // Redirect to staff_mang.php with an error message for invalid request method
    header("Location:  index.php?staff_mang?error=Invalid request method");
    exit();
}
?>

<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Update Staff</title>
</head>
<body>
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-6 offset-md-3">
                <div class="card">
                    <div class="card-header">
                        <h4>Update Staff</h4>
                    </div>
                    <div class="card-body">
                        <!-- Display success or error messages if any -->
                        <?php
                        if (isset($_GET['success'])) {
                            echo '<div class="alert alert-success">' . $_GET['success'] . '</div>';
                        } elseif (isset($_GET['error'])) {
                            echo '<div class="alert alert-danger">' . $_GET['error'] . '</div>';
                        }
                        ?>

                        <!-- Employee and Shift Update Form -->
                        <form method="POST" action="">
                            <!-- Employee Details -->
                            <input type="hidden" name="employeeID" value="<?php echo $employee['EmployeeID']; ?>">
                            <div class="mb-3">
                                <label for="firstName" class="form-label">First Name</label>
                                <input type="text" class="form-control" name="firstName" value="<?php echo $employee['FirstName']; ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="lastName" class="form-label">Last Name</label>
                                <input type="text" class="form-control" name="lastName" value="<?php echo $employee['LastName']; ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" class="form-control" name="email" value="<?php echo $employee['Email']; ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="phone" class="form-label">Phone</label>
                                <input type="text" class="form-control" name="phone" value="<?php echo $employee['Phone']; ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="positionType" class="form-label">Position Type</label>
                                <input type="text" class="form-control" name="positionType" value="<?php echo $employee['PositionType']; ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="nationalID" class="form-label">National ID</label>
                                <input type="text" class="form-control" name="nationalID" value="<?php echo $employee['NationalID']; ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="address" class="form-label">Address</label>
                                <textarea class="form-control" name="address" required><?php echo $employee['Address']; ?></textarea>
                            </div>

                            <!-- Shift Details -->
                            <input type="hidden" name="shiftID" value="<?php echo $shift['ShiftID']; ?>">
                            <div class="mb-3">
                                <label for="shiftStartTime" class="form-label">Shift Start Time</label>
                                <input type="time" class="form-control" name="shiftStartTime" value="<?php echo $shift['ShiftStartTime']; ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="shiftEndTime" class="form-label">Shift End Time</label>
                                <input type="time" class="form-control" name="shiftEndTime" value="<?php echo $shift['ShiftEndTime']; ?>" required>
                            </div>
                            
                         <a href="index.php? staff_mang">   <button type="submit" class="btn btn-primary">Update Staff</button>  </a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
