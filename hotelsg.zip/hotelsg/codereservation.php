<?php
session_start();
// Include your database connection file
include('db.php');

// Check if the form is submitted
if (isset($_POST['save_booking'])) {
    // Get form data
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $checkin_date = $_POST['checkin_date'];
    $checkout_date = $_POST['checkout_date'];
    $room_number = $_POST['room_number'];
    $adults = $_POST['adults'];
    $children = $_POST['children'];
    $total_amount = $_POST['total_amount'];
    $payment_method = $_POST['payment_method'];
    $payment_status = $_POST['payment_status'];
    $date_paid = $_POST['date_paid'];

    // Validate input data
    if (empty($first_name) || empty($last_name) || empty($email) || empty($phone) || empty($address) || empty($checkin_date) || empty($checkout_date) || empty($room_number) || empty($adults) || empty($children) || empty($total_amount) || empty($payment_method) || empty($payment_status) || empty($date_paid)) {
        // Redirect back to the form with an error message
        $_SESSION['message'] = 'All fields are required';
        header('Location: Addreservation.php');
        exit();
    }

    // Additional validation if needed...

    // Insert data into the guestdetails table using prepared statements
    $insertGuestQuery = "INSERT INTO guestdetails (FirstName, LastName, Email, Phone, Address) VALUES (?, ?, ?, ?, ?)";
    $stmtGuest = mysqli_prepare($connection, $insertGuestQuery);
    mysqli_stmt_bind_param($stmtGuest, "sssss", $first_name, $last_name, $email, $phone, $address);
    mysqli_stmt_execute($stmtGuest);
    mysqli_stmt_close($stmtGuest);

    // Get the auto-incremented GuestID
    $GuestID = mysqli_insert_id($connection);

    // Insert data into the reservationdetails table using prepared statements
    $insertReservationQuery = "INSERT INTO reservationdetails (GuestID, CheckInDate, CheckOutDate, RoomNumber, NumberOfAdults, NumberOfChildren) VALUES (?, ?, ?, ?, ?, ?)";
    $stmtReservation = mysqli_prepare($connection, $insertReservationQuery);
    mysqli_stmt_bind_param($stmtReservation, "isssii", $GuestID, $checkin_date, $checkout_date, $room_number, $adults, $children);
    mysqli_stmt_execute($stmtReservation);
    mysqli_stmt_close($stmtReservation);

    // Insert data into the paymentdetails table using prepared statements
    $insertPaymentQuery = "INSERT INTO paymentdetails (ReservationID, TotalAmount, PaymentMethod, PaymentStatus, DatePaid) VALUES (LAST_INSERT_ID(), ?, ?, ?, ?)";
    $stmtPayment = mysqli_prepare($connection, $insertPaymentQuery);
    mysqli_stmt_bind_param($stmtPayment, "dsss", $total_amount, $payment_method, $payment_status, $date_paid);
    mysqli_stmt_execute($stmtPayment);
    mysqli_stmt_close($stmtPayment);

    // Redirect to the form with a success message
    
    header('Location: Addreservation.php');
    exit();
} else {
    // Redirect to the form if the form is not submitted
    header('Location: Addreservation.php');
    exit();
}

// Close the database connection
mysqli_close($connection);
?>
