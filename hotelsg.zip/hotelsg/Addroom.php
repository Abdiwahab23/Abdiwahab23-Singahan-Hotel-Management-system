<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Add Room</title>
</head>
<body>

<div class="container mt-5">
    <div class="row">
        <div class="col-md-6 offset-md-3">
            <div class="card">
                <div class="card-header">
                    <h4>Add Room
                        <a href="index.php? room_mang" class="btn btn-danger float-end">BACK</a>
                    </h4>
                </div>
                <div class="card-body">

                    <form action="coderoom.php" method="POST">
                        <div class="mb-3">
                            <label for="guestId" class="form-label">Guest</label>
                            <select class="form-select" id="guestId" name="guestId" required>
                                <option value="" selected disabled>Select Guest</option>
                                <!-- Populate dropdown with guest data -->
                                <?php
                                require 'db.php';
                                $guestQuery = "SELECT GuestID, CONCAT(FirstName, ' ', LastName) AS FullName FROM guestdetails";
                                $guestResult = mysqli_query($connection, $guestQuery);
                                while ($guest = mysqli_fetch_assoc($guestResult)) {
                                    echo "<option value='{$guest['GuestID']}'>{$guest['FullName']}</option>";
                                }
                                ?>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label for="roomNumber" class="form-label">Room Number</label>
                            <select class="form-select" id="roomNumber" name="roomNumber" required>
                                <option value="" selected disabled>Select Room</option>
                                <!-- Populate dropdown with room data -->
                                <?php
                                $roomQuery = "SELECT RoomNumber FROM reservationdetails";
                                $roomResult = mysqli_query($connection, $roomQuery);
                                while ($room = mysqli_fetch_assoc($roomResult)) {
                                    echo "<option value='{$room['RoomNumber']}'>{$room['RoomNumber']}</option>";
                                }
                                ?>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label for="checkInDate" class="form-label">Check-in Date</label>
                            <input type="date" class="form-control" id="checkInDate" name="checkInDate" required>
                        </div>

                        <div class="mb-3">
                            <label for="checkOutDate" class="form-label">Check-out Date</label>
                            <input type="date" class="form-control" id="checkOutDate" name="checkOutDate" required>
                        </div>

                        <!-- Attributes from roomdetails table -->
                        <div class="mb-3">
                            <label for="roomType" class="form-label">Room Type</label>
                            <input type="text" class="form-control" id="roomType" name="roomType" required>
                        </div>

                        

                        <div class="mb-3">
                            <label for="pricePerNight" class="form-label">Price Per Night</label>
                            <input type="text" class="form-control" id="pricePerNight" name="pricePerNight" required>
                        </div>

                        <!-- Attributes from roomoccupancy table -->
                        <div class="mb-3">
                            <label for="occupancyId" class="form-label">Occupancy ID</label>
                            <input type="text" class="form-control" id="occupancyId" name="occupancyId" required>
                        </div>

                        <!-- Attributes from roomstatus table -->
                        <div class="mb-3">
                            <label for="statusId" class="form-label">Status ID</label>
                            <input type="text" class="form-control" id="statusId" name="statusId" required>
                        </div>

                        <div class="mb-3">
                            <label for="statusDate" class="form-label">Status Date</label>
                            <input type="date" class="form-control" id="statusDate" name="statusDate" required>
                        </div>

                        <div class="mb-3">
                            <label for="status" class="form-label">Status</label>
                            <input type="text" class="form-control" id="status" name="status" required>
                        </div>

                        <button type="submit" class="btn btn-primary" name="add_room">Add Room</button>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
