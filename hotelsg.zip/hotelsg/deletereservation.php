<?php
session_start();
require 'db.php';

if (isset($_GET['ReservationID']) && !empty($_GET['ReservationID'])) {
    $reservationID = $_GET['ReservationID'];

    // Check if the booking exists in the database
    $checkBookingQuery = "SELECT * FROM reservationdetails WHERE ReservationID = $reservationID";
    $checkBookingResult = mysqli_query($connection, $checkBookingQuery);

    if ($checkBookingResult && mysqli_num_rows($checkBookingResult) > 0) {
        // Delete the booking from the reservationdetails table
        $deleteReservationQuery = "DELETE FROM reservationdetails WHERE ReservationID = $reservationID";
        $deleteReservationResult = mysqli_query($connection, $deleteReservationQuery);

        // Delete the associated guest details
        $deleteGuestQuery = "DELETE FROM guestdetails WHERE GuestID = (SELECT GuestID FROM reservationdetails WHERE ReservationID = $reservationID)";
        $deleteGuestResult = mysqli_query($connection, $deleteGuestQuery);

        // Delete the associated payment details
        $deletePaymentQuery = "DELETE FROM paymentdetails WHERE ReservationID = $reservationID";
        $deletePaymentResult = mysqli_query($connection, $deletePaymentQuery);

        if ($deleteReservationResult !== false && $deleteGuestResult !== false && $deletePaymentResult !== false) {
            $_SESSION['message'] = 'Booking deleted successfully.';
        } else {
            $_SESSION['error'] = 'Error deleting booking: ' . mysqli_error($connection);
        }
    } else {
        $_SESSION['error'] = 'Booking not found.';
    }
} else {
    $_SESSION['error'] = 'Invalid ReservationID.';
}

header('Location: index.php?reservation');
exit();
?>
