<?php
include_once 'db.php';

if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $query = "SELECT * FROM userdetails WHERE Username = '$username' AND Password='$password'";
    $result = mysqli_query($connection, $query);

    $userdetails = mysqli_fetch_assoc($result);

    if ($userdetails['Role'] == 'owner') {
        header('Location: index.php?room_mang');
    } else {
        header('Location: login.php');
    }
}

if (isset($_POST['submit'])) {
    // Your existing code for updating staff
}

if (isset($_GET['empid'])!="") {
   // Your existing code for deleting staff
}
?>
