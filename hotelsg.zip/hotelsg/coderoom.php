<?php
session_start();

// Include your database connection file
require 'db.php';

// Check if the form is submitted
if (isset($_POST['add_room'])) {
    // Get form data
    $guestId = $_POST['guestId'];
    $roomNumber = $_POST['roomNumber'];
    $checkInDate = $_POST['checkInDate'];
    $checkOutDate = $_POST['checkOutDate'];
    $roomType = $_POST['roomType'];
    $roomStatus = $_POST['roomStatus'];
    $pricePerNight = $_POST['pricePerNight'];
    $occupancyId = $_POST['occupancyId'];
    $statusId = $_POST['statusId'];
    $statusDate = $_POST['statusDate'];
    $status = $_POST['status'];

    // Validate input data
    // Add your validation logic here...

    // Insert data into roomoccupancy table
    $insertOccupancyQuery = "INSERT INTO roomoccupancy (OccupancyID, RoomNumber, GuestID, CheckInDate, CheckOutDate) VALUES (?, ?, ?, ?, ?)";
    $stmtOccupancy = mysqli_prepare($connection, $insertOccupancyQuery);
    mysqli_stmt_bind_param($stmtOccupancy, "iiiss", $occupancyId, $roomNumber, $guestId, $checkInDate, $checkOutDate);
    mysqli_stmt_execute($stmtOccupancy);
    mysqli_stmt_close($stmtOccupancy);

    // Insert data into roomdetails table
    $insertDetailsQuery = "INSERT INTO roomdetails (RoomNumber, RoomType, PricePerNight) VALUES (?, ?, ?)";
    $stmtDetails = mysqli_prepare($connection, $insertDetailsQuery);
    mysqli_stmt_bind_param($stmtDetails, "iss", $roomNumber, $roomType, $pricePerNight);
    mysqli_stmt_execute($stmtDetails);
    mysqli_stmt_close($stmtDetails);

    // Insert data into roomstatus table
    $insertStatusQuery = "INSERT INTO roomstatus (StatusID, RoomNumber, Date, Status) VALUES (?, ?, ?, ?)";
    $stmtStatus = mysqli_prepare($connection, $insertStatusQuery);
    mysqli_stmt_bind_param($stmtStatus, "iiss", $statusId, $roomNumber, $statusDate, $status);
    mysqli_stmt_execute($stmtStatus);
    mysqli_stmt_close($stmtStatus);

    // Redirect to the form with a success message
    $_SESSION['message'] = 'Room added successfully';
    header('Location: Addroom.php');
    exit();
} else {
    // Redirect to the form if the form is not submitted
    header('Location: Addroom.php');
    exit();
}

// Close the database connection
mysqli_close($connection);
?>
