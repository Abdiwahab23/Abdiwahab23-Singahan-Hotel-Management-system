<?php
session_start();

// Include your database connection file
require 'db.php';

// Check if the room number is set in the URL
if (isset($_GET['RoomNumber'])) {
    // Get the room number from the URL
    $roomNumber = $_GET['RoomNumber'];

    // Fetch the existing room details from the database
    $roomQuery = "SELECT rd.*, ro.OccupancyID, ro.GuestID, ro.CheckInDate AS OccupancyCheckInDate, ro.CheckOutDate AS OccupancyCheckOutDate, rs.StatusID, rs.Date AS StatusDate, rs.Status AS RoomStatus
                  FROM roomdetails rd
                  LEFT JOIN roomoccupancy ro ON rd.RoomNumber = ro.RoomNumber
                  LEFT JOIN roomstatus rs ON rd.RoomNumber = rs.RoomNumber
                  WHERE rd.RoomNumber = $roomNumber";

    $result = mysqli_query($connection, $roomQuery);

    if ($result && mysqli_num_rows($result) > 0) {
        $roomDetails = mysqli_fetch_assoc($result);

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_room'])) {
            // Perform the delete operation in the roomdetails table
            $deleteRoomQuery = "DELETE FROM roomdetails WHERE RoomNumber = $roomNumber";
            $deleteRoomResult = mysqli_query($connection, $deleteRoomQuery);

            // Perform the delete operation in the roomoccupancy table
            $deleteOccupancyQuery = "DELETE FROM roomoccupancy WHERE RoomNumber = $roomNumber";
            $deleteOccupancyResult = mysqli_query($connection, $deleteOccupancyQuery);

            // Perform the delete operation in the roomstatus table
            $deleteStatusQuery = "DELETE FROM roomstatus WHERE RoomNumber = $roomNumber";
            $deleteStatusResult = mysqli_query($connection, $deleteStatusQuery);

            if ($deleteRoomResult !== false && $deleteOccupancyResult !== false && $deleteStatusResult !== false) {
                $_SESSION['message'] = 'Room deleted successfully.';
                header('Location: index.php?room_mang');
                exit();
            } else {
                $_SESSION['error'] = 'Error deleting room: ' . mysqli_error($connection);
            }
        }
    } else {
        $_SESSION['error'] = 'Room not found.';
        header('Location: index.php?room_mang');
        exit();
    }
} else {
    $_SESSION['error'] = 'Invalid RoomNumber.';
    header('Location: index.php?room_mang');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Delete Room</title>
</head>

<body>

    <div class="container mt-4">
        <?php include('message.php'); ?>

        <div class="row mb-3">
            <div class="col-md-12">
                <a href="index.php?room" class="btn btn-primary">Back to View</a>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Delete Room</h4>
                    </div>
                    <div class="card-body">
                        <p>Are you sure you want to delete this room?</p>
                        <form action="deleteroom.php?RoomNumber=<?= $roomNumber; ?>" method="POST">
                            <button type="submit" name="delete_room" class="btn btn-danger">Delete Room</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>
