<?php
require 'db.php'; // Assuming your database connection file is named 'db.php'

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    // Check if BillID is set in the URL
    if(isset($_GET["BillID"]) && is_numeric($_GET["BillID"])) {
        $billID = $_GET["BillID"];

        // Prepare a delete query
        $deleteQuery = "DELETE FROM billingdetails WHERE BillID = $billID";

        // Execute the delete query
        if(mysqli_query($connection, $deleteQuery)) {
            // Redirect to billing.php with a success message
            header("Location: index.php? billing");
            exit();
        } else {
            // Redirect to billing.php with an error message
            header("Location: index.php? billing?error=Error deleting billing details: " . mysqli_error($connection));
            exit();
        }
    } else {
        // Redirect to billing.php with an error message
        header("Location: index.php? billing?error=Invalid BillID");
        exit();
    }
} else {
    // Redirect to billing.php with an error message
    header("Location: index.php? billing?error=Invalid request method");
    exit();
}
?>
