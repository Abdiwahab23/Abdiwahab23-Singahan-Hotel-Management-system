<a href="index.php?staff_mang" class="btn btn-primary">Back to View</a>
<?php
require 'db.php'; // Assuming your database connection file is named 'db.php'

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Fetch data from the form for employee details
    $employeeID = $_POST['employeeID'];
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $positionType = $_POST['positionType'];
    $nationalID = $_POST['nationalID'];
    $address = $_POST['address'];

    // Insert data into employeedetails table
    $insertEmployeeQuery = "INSERT INTO employeedetails (EmployeeID, FirstName, LastName, Email, Phone, PositionType, NationalID, Address) 
                            VALUES ('$employeeID', '$firstName', '$lastName', '$email', '$phone', '$positionType', '$nationalID', '$address')";
    
    if (mysqli_query($connection, $insertEmployeeQuery)) {
        // Fetch data from the form for shift details
        $shiftID = $_POST['shiftID'];
        $shiftStartTime = $_POST['shiftStartTime'];
        $shiftEndTime = $_POST['shiftEndTime'];

        // Insert data into employeeshift table
        $insertShiftQuery = "INSERT INTO employeeshift (ShiftID, EmployeeID, ShiftStartTime, ShiftEndTime) 
                             VALUES ('$shiftID', '$employeeID', '$shiftStartTime', '$shiftEndTime')";

        if (mysqli_query($connection, $insertShiftQuery)) {
            // Redirect to staff_mang.php with a success message
            header("Location: index.php?staff_mang");
            exit();
        } else {
            // Redirect to staff_mang.php with an error message
            header("Location: index.php?staff_mang error=Error adding shift: " . mysqli_error($connection));
            exit();
        }
    } else {
        // Redirect to staff_mang.php with an error message
        header("Location:index.php?staff_mang ?error=Error adding employee: " . mysqli_error($connection));
        exit();
    }
}
?>

<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Add Employee and Shift</title>
</head>
<body>
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-6 offset-md-3">
                <div class="card">
                    <div class="card-header">
                        <h4>Add Employee and Shift</h4>
                    </div>
                    <div class="card-body">
                        <!-- Display success or error messages if any -->
                        <?php
                        if (isset($_GET['success'])) {
                            echo '<div class="alert alert-success">' . $_GET['success'] . '</div>';
                        } elseif (isset($_GET['error'])) {
                            echo '<div class="alert alert-danger">' . $_GET['error'] . '</div>';
                        }
                        ?>

                        <!-- Employee and Shift Form -->
                        <form method="POST" action="">
                            <!-- Employee Details -->
                            <div class="mb-3">
                                <label for="employeeID" class="form-label">Employee ID</label>
                                <input type="text" class="form-control" name="employeeID" required>
                            </div>
                            <div class="mb-3">
                                <label for="firstName" class="form-label">First Name</label>
                                <input type="text" class="form-control" name="firstName" required>
                            </div>
                            <div class="mb-3">
                                <label for="lastName" class="form-label">Last Name</label>
                                <input type="text" class="form-control" name="lastName" required>
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" class="form-control" name="email" required>
                            </div>
                            <div class="mb-3">
                                <label for="phone" class="form-label">Phone</label>
                                <input type="text" class="form-control" name="phone" required>
                            </div>
                            <div class="mb-3">
                                <label for="positionType" class="form-label">Position Type</label>
                                <input type="text" class="form-control" name="positionType" required>
                            </div>
                            <div class="mb-3">
                                <label for="nationalID" class="form-label">National ID</label>
                                <input type="text" class="form-control" name="nationalID" required>
                            </div>
                            <div class="mb-3">
                                <label for="address" class="form-label">Address</label>
                                <textarea class="form-control" name="address" required></textarea>
                            </div>

                            <!-- Shift Details -->
                            <div class="mb-3">
                                <label for="shiftID" class="form-label">Shift ID</label>
                                <input type="text" class="form-control" name="shiftID" required>
                            </div>
                            <div class="mb-3">
                                <label for="shiftStartTime" class="form-label">Shift Start Time</label>
                                <input type="time" class="form-control" name="shiftStartTime" required>
                            </div>
                            <div class="mb-3">
                                <label for="shiftEndTime" class="form-label">Shift End Time</label>
                                <input type="time" class="form-control" name="shiftEndTime" required>
                            </div>
                            
                           <a href="index.php?staff_mang"> " <button type="submit" class="btn btn-primary">Add Employee and Shift</button></a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
