<?php
require 'db.php';

// Fetch employee data for dropdown in userdetails form
$employeeQueryUser = "SELECT EmployeeID, CONCAT(FirstName, ' ', LastName) AS FullName FROM employeedetails";
$employeeResultUser = mysqli_query($connection, $employeeQueryUser);

// Fetch user data for dropdown in userpermissions form
$userQuery = "SELECT UserID, Username FROM userdetails";
$userResult = mysqli_query($connection, $userQuery);
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Add User</title>
</head>
<body>

<div class="container mt-5">
 <a href="index.php? dashboard" class="btn btn-primary">Back</a>
    <div class="row">
   
        <div class="col-md-6 offset-md-3">
            <div class="card">
                <div class="card-header">
                    <h4>Add User</h4>
                </div>
                <div class="card-body">

                    <!-- Form for userdetails -->
                    <form action="codeuser.php" method="POST">
                        <input type="hidden" name="add_user" value="1">

                        <div class="mb-3">
                            <label for="employeeIdUser" class="form-label">Employee ID</label>
                            <select class="form-select" id="employeeIdUser" name="employeeIdUser" required>
                                <option value="" selected disabled>Select Employee</option>
                                <?php
                                while ($employeeUser = mysqli_fetch_assoc($employeeResultUser)) {
                                    echo "<option value='{$employeeUser['EmployeeID']}'>{$employeeUser['FullName']}</option>";
                                }
                                ?>
                            </select>
                            

                        <div class="mb-3">
                            <label for="username" class="form-label">Username</label>
                            <input type="text" class="form-control" id="username" name="username" required>
                        </div>

                        <div class="mb-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" class="form-control" id="password" name="password" required>
                        </div>

                        <div class="mb-3">
                            <label for="role" class="form-label">Role</label>
                            <input type="text" class="form-control" id="role" name="role" required>
                        </div>

                        <button type="submit" class="btn btn-primary">Save User Details</button>
                    </form>

                    <!-- Form for userpermissions -->
                    <form action="codeuser.php" method="POST" class="mt-3">
                        <input type="hidden" name="add_permission" value="1">

                        <div class="mb-3">
                            <label for="userId" class="form-label">User ID</label>
                            <select class="form-select" id="userId" name="userId" required>
                                <option value="" selected disabled>Select User</option>
                                <?php
                                mysqli_data_seek($userResult, 0); // Reset result pointer
                                while ($user = mysqli_fetch_assoc($userResult)) {
                                    echo "<option value='{$user['UserID']}'>{$user['Username']}</option>";
                                }
                                ?>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label for="permissionId" class="form-label">Permission ID</label>
                            <input type="text" class="form-control" id="permissionId" name="permissionId" required>
                        </div>

                        <div class="mb-3">
                            <label for="moduleName" class="form-label">Module Name</label>
                            <input type="text" class="form-control" id="moduleName" name="moduleName" required>
                        </div>

                        <div class="mb-3 form-check">
                            <input type="checkbox" class="form-check-input" id="canRead" name="canRead">
                            <label class="form-check-label" for="canRead">Can Read</label>
                        </div>

                        <div class="mb-3 form-check">
                            <input type="checkbox" class="form-check-input" id="canWrite" name="canWrite">
                            <label class="form-check-label" for="canWrite">Can Write</label>
                        </div>

                        <div class="mb-3 form-check">
                            <input type="checkbox" class="form-check-input" id="canDelete" name="canDelete">
                            <label class="form-check-label" for="canDelete">Can Delete</label>
                        </div>

                        <button type="submit" class="btn btn-primary">Save User Permissions</button>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
