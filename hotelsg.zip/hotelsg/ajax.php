<?php
include_once 'db.php';
session_start();

if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    if (empty($email) || empty($password)) {
        header('Location: login.php?empty');
    } else {
        // Since passwords are stored as plaintext in the database, no need to md5 hash them
        $query = "SELECT * FROM userdetails WHERE Username = '$email' AND Password='$password'";
        $result = mysqli_query($connection, $query);

        if (mysqli_num_rows($result) == 1) {
            $user = mysqli_fetch_assoc($result);
            $_SESSION['username'] = $user['Username'];
            $_SESSION['user_id'] = $user['UserID'];
            header('Location: index.php?dashboard');
        } else {
            header('Location: login.php?loginE');
        }
    }
}
// Rest of the code remains unchanged
?>
