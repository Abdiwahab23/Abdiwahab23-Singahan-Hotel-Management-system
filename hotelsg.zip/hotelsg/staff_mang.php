<?php
require 'db.php'; // Assuming your database connection file is named 'db.php'
?>

<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Staff Management</title>
    <style>
        body{
            margin:0;
            padding:0;
        }
        .col-md-12{
            margin-left:100px;
            margin-top:-560px;
        }
        .row{
            max-width:1230px;
        }
        .row-names{
            font-size:12px;
        }

        
    </style>
</head>
<body>
    

    <div class="container mt-4">
        <?php include('message.php'); ?>

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Staff Management
                            <a href="AddStaff.php" class="btn btn-primary float-end">Add Staff</a>
                        </h4>
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered table-striped">
                            <thead>
                            <tr class="row-names">
                                <th>Employee ID</th>
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Position Type</th>
                                <th>National ID</th>
                                <th>Address</th>
                                <th>Shift ID</th>
                                <th>Shift Start Time</th>
                                <th>Shift End Time</th>
                                <th>Action</th>
                            </tr>
                            </thead>

                            <?php
                            $staffQuery = "SELECT ed.EmployeeID, ed.FirstName, ed.LastName, ed.Email, ed.Phone, ed.PositionType, ed.NationalID, ed.Address, es.ShiftID, es.ShiftStartTime, es.ShiftEndTime
                                          FROM employeedetails ed
                                          LEFT JOIN employeeshift es ON ed.EmployeeID = es.EmployeeID";
                            $staffResult = mysqli_query($connection, $staffQuery);

                            if (mysqli_num_rows($staffResult) > 0) {
                                foreach ($staffResult as $row) {
                                    ?>
                                    <tr>
                                        <td><?= $row['EmployeeID']; ?></td>
                                        <td><?= $row['FirstName']; ?></td>
                                        <td><?= $row['LastName']; ?></td>
                                        <td><?= $row['Email']; ?></td>
                                        <td><?= $row['Phone']; ?></td>
                                        <td><?= $row['PositionType']; ?></td>
                                        <td><?= $row['NationalID']; ?></td>
                                        <td><?= $row['Address']; ?></td>
                                        <td><?= $row['ShiftID']; ?></td>
                                        <td><?= $row['ShiftStartTime']; ?></td>
                                        <td><?= $row['ShiftEndTime']; ?></td>
                                        <td>
                                            <!-- Add your actions here, e.g., update and delete links or buttons -->
                                            <a href="updatestaff.php?EmployeeID=<?= $row['EmployeeID']; ?>" class="btn btn-primary btn-sm">Update</a>
                                            <a href="deletestaff.php?EmployeeID=<?= $row['EmployeeID']; ?>" class="btn btn-danger btn-sm">Delete</a>
                                            <form action="deletestaff.php" method="POST" class="d-inline">
                                                <input type="hidden" name="EmployeeID" value="<?= $row['EmployeeID']; ?>">
                                                <!-- Add any additional hidden inputs if needed -->
                                                
                                            </form>
                                        </td>
                                    </tr>
                                    <?php
                                }
                            } else {
                                echo "<tr><td colspan='12'>No staff data available</td></tr>";
                            }
                            ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
