<?php
require 'db.php';

if (isset($_POST['add_user'])) {
    // Process userdetails form submission
    $employeeIdUser = mysqli_real_escape_string($connection, $_POST['employeeIdUser']);
    $username = mysqli_real_escape_string($connection, $_POST['username']);
    $password = mysqli_real_escape_string($connection, $_POST['password']); // Get plain text password
    $role = mysqli_real_escape_string($connection, $_POST['role']);

    // For debugging purposes, display the plain text password (remove this in production)
    

    $insertUserQuery = "INSERT INTO userdetails (Username, Password, Role, EmployeeID) VALUES ('$username', '$password', '$role', '$employeeIdUser')";

    if (mysqli_query($connection, $insertUserQuery)) {
        echo "User details added successfully.";
    } else {
        echo "Error: " . mysqli_error($connection);
    }
}

if (isset($_POST['add_permission'])) {
    // Process userpermissions form submission
    $userId = mysqli_real_escape_string($connection, $_POST['userId']);
    $permissionId = mysqli_real_escape_string($connection, $_POST['permissionId']);
    $moduleName = mysqli_real_escape_string($connection, $_POST['moduleName']);
    $canRead = isset($_POST['canRead']) ? 1 : 0;
    $canWrite = isset($_POST['canWrite']) ? 1 : 0;
    $canDelete = isset($_POST['canDelete']) ? 1 : 0;

    $insertPermissionQuery = "INSERT INTO userpermissions (UserID, PermissionID, ModuleName, CanRead, CanWrite, CanDelete) VALUES ('$userId', '$permissionId', '$moduleName', '$canRead', '$canWrite', '$canDelete')";

    if (mysqli_query($connection, $insertPermissionQuery)) {
        echo "User permissions added successfully.";
    } else {
        echo "Error: " . mysqli_error($connection);
    }
}

mysqli_close($connection);
?>
