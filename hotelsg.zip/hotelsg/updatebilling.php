<?php
require 'db.php'; // Assuming your database connection file is named 'db.php'

// Function to fetch data from a table and return it as an associative array
function fetchDropdownData($connection, $tableName, $idColumn, $nameColumn) {
    $query = "SELECT $idColumn, $nameColumn FROM $tableName";
    $result = mysqli_query($connection, $query);
    $data = array();

    while ($row = mysqli_fetch_assoc($result)) {
        $data[] = $row;
    }

    return $data;
}

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    // Check if BillID is set in the URL
    if(isset($_GET["BillID"]) && is_numeric($_GET["BillID"])) {
        $billID = $_GET["BillID"];

        // Fetch billing details for the selected BillID
        $selectQuery = "SELECT * FROM billingdetails WHERE BillID = $billID";
        $result = mysqli_query($connection, $selectQuery);

        if (mysqli_num_rows($result) == 1) {
            $billingDetails = mysqli_fetch_assoc($result);

            // Fetch data for dropdowns
            $guests = fetchDropdownData($connection, 'guestdetails', 'GuestID', 'FirstName');
            $reservations = fetchDropdownData($connection, 'reservationdetails', 'ReservationID', 'ReservationID');
            $paymentData = fetchDropdownData($connection, 'paymentdetails', 'PaymentID', 'TotalAmount');
        } else {
            // Redirect to billing.php with an error message
            header("Location: billing.php?error=Invalid BillID");
            exit();
        }
    } else {
        // Redirect to billing.php with an error message
        header("Location: billing.php?error=Invalid BillID");
        exit();
    }
} elseif ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Fetch data from the form for billing details
    $billID = $_POST['billID'];
    $reservationID = $_POST['reservationID'];
    $guestID = $_POST['guestID'];
    $totalAmount = $_POST['totalAmount'];
    $taxAmount = $_POST['taxAmount'];
    $discountAmount = $_POST['discountAmount'];

    // Update data in billingdetails table
    $updateBillingQuery = "UPDATE billingdetails 
                           SET ReservationID = '$reservationID', GuestID = '$guestID', TotalAmount = '$totalAmount', 
                           TaxAmount = '$taxAmount', DiscountAmount = '$discountAmount' 
                           WHERE BillID = $billID";

    if (mysqli_query($connection, $updateBillingQuery)) {
        // Redirect to billing.php with a success message
        header("Location: index.php?billing");
        exit();
    } else {
        // Redirect to billing.php with an error message
        header("Location: billing.php?error=Error updating billing details: " . mysqli_error($connection));
        exit();
    }
} else {
    // Redirect to billing.php with an error message
    header("Location: billing.php?error=Invalid request method");
    exit();
}
?>

<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Update Billing Details</title>
</head>
<body>
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-6 offset-md-3">
                <div class="card">
                    <div class="card-header">
                        <h4>Update Billing Details</h4>
                    </div>
                    <div class="card-body">
                        <!-- Display success or error messages if any -->
                        <?php
                        if (isset($_GET['error'])) {
                            echo '<div class="alert alert-danger">' . $_GET['error'] . '</div>';
                        }
                        ?>

                        <!-- Billing Details Form -->
                        <form method="POST" action="">
                            <div class="mb-3">
                                <label for="billID" class="form-label">Bill ID</label>
                                <input type="text" class="form-control" name="billID" value="<?= $billingDetails['BillID']; ?>" readonly>
                            </div>
                            <div class="mb-3">
                                <label for="reservationID" class="form-label">Reservation ID</label>
                                <select class="form-select" name="reservationID" required>
                                    <?php foreach ($reservations as $reservation): ?>
                                        <option value="<?= $reservation['ReservationID']; ?>" <?= ($reservation['ReservationID'] == $billingDetails['ReservationID']) ? 'selected' : ''; ?>>
                                            <?= $reservation['ReservationID']; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="guestID" class="form-label">Guest ID</label>
                                <select class="form-select" name="guestID" required>
                                    <?php foreach ($guests as $guest): ?>
                                        <option value="<?= $guest['GuestID']; ?>" <?= ($guest['GuestID'] == $billingDetails['GuestID']) ? 'selected' : ''; ?>>
                                            <?= $guest['FirstName']; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="totalAmount" class="form-label">Total Amount</label>
                                <select class="form-select" name="totalAmount" required>
                                    <?php foreach ($paymentData as $payment): ?>
                                        <option value="<?= $payment['TotalAmount']; ?>" <?= ($payment['TotalAmount'] == $billingDetails['TotalAmount']) ? 'selected' : ''; ?>>
                                            <?= $payment['TotalAmount']; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="taxAmount" class="form-label">Tax Amount</label>
                                <input type="text" class="form-control" name="taxAmount" value="<?= $billingDetails['TaxAmount']; ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="discountAmount" class="form-label">Discount Amount</label>
                                <input type="text" class="form-control" name="discountAmount" value="<?= $billingDetails['DiscountAmount']; ?>" required>
                            </div>
                            <button type="submit" class="btn btn-primary">Update Billing Details</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
