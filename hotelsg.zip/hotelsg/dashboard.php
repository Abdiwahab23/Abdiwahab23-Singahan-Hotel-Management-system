<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hotel Management Dashboard</title>
    <style>
        body {
            background-color: #f0f0f0;
            font-family: 'Arial', sans-serif;
			
        }
				.col-sm-6{
					width:300px;
				}
        .container {
						width:1250px;
            margin-top: -540px;
						margin-left:190px;
        }

        .breadcrumb {
            background-color: #4da6ff;
            color: white;
        }

        .breadcrumb .fa-home {
            color: white;
        }
				.breadcrumb li.active {
        color: white; /* Set the desired text color for the active li element */
   			 }

        .dashboard-section {
            margin-top: 20px;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 5px;
        }

        .dashboard-section h2 {
            color: #333;
						font-size:25px;
        }

        .dashboard-metric {
            margin-top: 10px;
            padding: 15px;
            background-color: #e0e0e0;
            border-radius: 5px;
        }
				.row{
					margin:0;
					padding:0;
				}

				.last-section{
					margin-left:300px;
				}
    </style>
</head>
<body>

<div class="container">
    <div class="row" style="margin:0px;">
        <ol class="breadcrumb">
            <li><a href="#"><em class="fa fa-home"></em></a></li>
            <li class="active">Dashboard</li>
        </ol>
    </div><!--/.row-->

    <div class="row">
        <!-- Add this section in your dashboard code -->
<div class="col-sm-6">
    <div class="dashboard-section">
        <h2>Booked Rooms</h2>
        <div class="dashboard-metric">
            <?php
                // Assuming you have a database connection
                require 'db.php';

                // Your SQL query to fetch the total number of booked rooms
                $totalBookedRoomsQuery = "SELECT COUNT(DISTINCT ro.RoomNumber) AS TotalBookedRooms
                                          FROM roomoccupancy ro
                                          WHERE ro.CheckOutDate >= CURDATE()";

                $totalBookedRoomsResult = mysqli_query($connection, $totalBookedRoomsQuery);

                if ($totalBookedRoomsResult) {
                    $totalBookedRooms = mysqli_fetch_assoc($totalBookedRoomsResult)['TotalBookedRooms'];
                    echo "<p>Total Booked Rooms: <strong>{$totalBookedRooms}</strong></p>";
                } else {
                    echo "<p>Unable to fetch booked rooms data</p>";
                }

                // Close the database connection
                mysqli_close($connection);
            ?>
        </div>
    </div>
</div>


				<!-- Add this section in your dashboard code -->
<div class="col-sm-6">
    <div class="dashboard-section">
        <h2>Staff Number</h2>
        <div class="dashboard-metric">
            <?php
                // Assuming you have a database connection
                require 'db.php';

                // Your SQL query to fetch the total number of staff members
                $totalStaffQuery = "SELECT COUNT(EmployeeID) AS TotalStaffMembers
                                    FROM employeedetails";

                $totalStaffResult = mysqli_query($connection, $totalStaffQuery);

                if ($totalStaffResult) {
                    $totalStaffMembers = mysqli_fetch_assoc($totalStaffResult)['TotalStaffMembers'];
                    echo "<p>Total Staff Numbers: <strong>{$totalStaffMembers}</strong></p>";
                } else {
                    echo "<p>Unable to fetch staff members data</p>";
                }

                // Close the database connection
                mysqli_close($connection);
            ?>
        </div>
    </div>
</div>


				<!-- Add this section in your dashboard code -->
<div class="col-sm-6">
    <div class="dashboard-section">
        <h2>Guests</h2>
        <div class="dashboard-metric">
            <?php
                // Assuming you have a database connection
                require 'db.php';

                // Your SQL query to fetch the total number of guests
                $totalGuestsQuery = "SELECT COUNT(DISTINCT rd.GuestID) AS TotalGuests
                                     FROM reservationdetails rd
                                     JOIN paymentdetails pd ON rd.ReservationID = pd.ReservationID";

                $totalGuestsResult = mysqli_query($connection, $totalGuestsQuery);

                if ($totalGuestsResult) {
                    $totalGuests = mysqli_fetch_assoc($totalGuestsResult)['TotalGuests'];
                    echo "<p>Total Guests: <strong>{$totalGuests}</strong></p>";
                } else {
                    echo "<p>Unable to fetch guests data</p>";
                }

                // Close the database connection
                mysqli_close($connection);
            ?>
        </div>
    </div>
</div>


				<!-- Add this section in your dashboard code -->
<div class="col-sm-6">
    <div class="dashboard-section">
        <h2>Users Number</h2>
        <div class="dashboard-metric">
            <?php
                // Assuming you have a database connection
                require 'db.php';

                // Your SQL query to fetch the total number of users
                $totalUsersQuery = "SELECT COUNT(UserID) AS TotalUsers
                                    FROM userdetails";

                $totalUsersResult = mysqli_query($connection, $totalUsersQuery);

                if ($totalUsersResult) {
                    $totalUsers = mysqli_fetch_assoc($totalUsersResult)['TotalUsers'];
                    echo "<p>Total Users: <strong>{$totalUsers}</strong></p>";
                } else {
                    echo "<p>Unable to fetch users data</p>";
                }

                // Close the database connection
                mysqli_close($connection);
            ?>
        </div>
    </div>
</div>

		<div class="last-section">
		<!-- Add this section in your dashboard code -->
<div class="col-sm-6">
    <div class="dashboard-section">
        <h2>Total Income</h2>
        <div class="dashboard-metric">
            <?php
                // Assuming you have a database connection
                require 'db.php';

                // Your SQL query to calculate the total income
                $totalIncomeQuery = "SELECT SUM(pd.TotalAmount) AS TotalIncome
                                    FROM paymentdetails pd
                                    JOIN reservationdetails rd ON pd.ReservationID = rd.ReservationID";

                $totalIncomeResult = mysqli_query($connection, $totalIncomeQuery);

                if ($totalIncomeResult) {
                    $totalIncome = mysqli_fetch_assoc($totalIncomeResult)['TotalIncome'];
                    echo "<p>Total Income:RM <strong>{$totalIncome}</strong></p>";
                } else {
                    echo "<p>Unable to fetch total income data</p>";
                }

                // Close the database connection
                mysqli_close($connection);
            ?>
        </div>
    </div>
</div>


				<!-- Add this section in your dashboard code -->
<div class="col-sm-6">
    <div class="dashboard-section">
        <h2>Total Pending</h2>
        <div class="dashboard-metric">
            <?php
                // Assuming you have a database connection
                require 'db.php';

                // Your SQL query to count the pending reservations
                $pendingQuery = "SELECT COUNT(*) AS TotalPending
                                FROM reservationdetails rd
                                JOIN paymentdetails pd ON rd.ReservationID = pd.ReservationID
                                WHERE pd.PaymentStatus = 'Pending'";

                $pendingResult = mysqli_query($connection, $pendingQuery);

                if ($pendingResult) {
                    $totalPending = mysqli_fetch_assoc($pendingResult)['TotalPending'];
                    echo "<p>Total Pending: <strong>{$totalPending}</strong></p>";
                } else {
                    echo "<p>Unable to fetch total pending data</p>";
                }

                // Close the database connection
                mysqli_close($connection);
            ?>
        </div>
    </div>
</div>


    <!-- Add similar sections for reservations, billing, etc. -->

</div><!--/.container-->

</body>
</html>
