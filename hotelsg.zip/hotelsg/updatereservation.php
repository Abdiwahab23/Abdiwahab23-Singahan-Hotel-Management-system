<?php

require 'db.php'; // Assuming your database connection file is named 'db.php'

// Check if ReservationID is set and not empty
if (isset($_GET['ReservationID']) && !empty($_GET['ReservationID'])) {
    $reservationID = $_GET['ReservationID'];

    // Fetch the existing booking details from the database
    $bookingQuery = "SELECT 
                    rd.ReservationID, 
                    rd.CheckInDate, 
                    rd.CheckOutDate, 
                    rd.RoomNumber, 
                    rd.NumberOfAdults, 
                    rd.NumberOfChildren,
                    gd.FirstName, 
                    gd.LastName, 
                    gd.Email, 
                    gd.Phone, 
                    gd.Address,
                    pd.PaymentID, 
                    pd.TotalAmount, 
                    pd.PaymentMethod, 
                    pd.PaymentStatus, 
                    pd.DatePaid
                FROM reservationdetails rd
                JOIN guestdetails gd ON rd.GuestID = gd.GuestID
                JOIN paymentdetails pd ON rd.ReservationID = pd.ReservationID
                WHERE rd.ReservationID = $reservationID";

    $result = mysqli_query($connection, $bookingQuery);

    if ($result && mysqli_num_rows($result) > 0) {
        $bookingDetails = mysqli_fetch_assoc($result);

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_booking'])) {
            // Collect updated data from the form
            $updatedCheckInDate = $_POST['updatedCheckInDate'] ?? $bookingDetails['CheckInDate'];
            $updatedCheckOutDate = $_POST['updatedCheckOutDate'] ?? $bookingDetails['CheckOutDate'];
            $updatedRoomNumber = $_POST['updatedRoomNumber'] ?? $bookingDetails['RoomNumber'];
            $updatedNumberOfAdults = $_POST['updatedNumberOfAdults'] ?? $bookingDetails['NumberOfAdults'];
            $updatedNumberOfChildren = $_POST['updatedNumberOfChildren'] ?? $bookingDetails['NumberOfChildren'];

            // Perform the update in the reservationdetails table
            $updateReservationQuery = "UPDATE reservationdetails 
                                       SET 
                                           CheckInDate = '$updatedCheckInDate', 
                                           CheckOutDate = '$updatedCheckOutDate', 
                                           RoomNumber = '$updatedRoomNumber', 
                                           NumberOfAdults = '$updatedNumberOfAdults', 
                                           NumberOfChildren = '$updatedNumberOfChildren'
                                       WHERE ReservationID = $reservationID";

            $updateReservationResult = mysqli_query($connection, $updateReservationQuery);

            // Collect updated guest details from the form
            $updatedFirstName = $_POST['updatedFirstName'] ?? $bookingDetails['FirstName'];
            $updatedLastName = $_POST['updatedLastName'] ?? $bookingDetails['LastName'];
            $updatedEmail = $_POST['updatedEmail'] ?? $bookingDetails['Email'];
            $updatedPhone = $_POST['updatedPhone'] ?? $bookingDetails['Phone'];
            $updatedAddress = $_POST['updatedAddress'] ?? $bookingDetails['Address'];

            // Perform the update in the guestdetails table
            $updateGuestQuery = "UPDATE guestdetails 
                                 SET 
                                     FirstName = '$updatedFirstName', 
                                     LastName = '$updatedLastName', 
                                     Email = '$updatedEmail', 
                                     Phone = '$updatedPhone', 
                                     Address = '$updatedAddress'
                                 WHERE GuestID = (SELECT GuestID FROM reservationdetails WHERE ReservationID = $reservationID)";

            $updateGuestResult = mysqli_query($connection, $updateGuestQuery);

            // Collect updated payment details from the form
            $updatedPaymentMethod = $_POST['updatedPaymentMethod'] ?? $bookingDetails['PaymentMethod'];
            $updatedTotalAmount = $_POST['updatedTotalAmount'] ?? $bookingDetails['TotalAmount'];
            $updatedPaymentStatus = $_POST['updatedPaymentStatus'] ?? $bookingDetails['PaymentStatus'];
            $updatedDatePaid = $_POST['updatedDatePaid'] ?? $bookingDetails['DatePaid'];

            // Perform the update in the paymentdetails table
            $updatePaymentQuery = "UPDATE paymentdetails 
                                   SET 
                                       PaymentMethod = '$updatedPaymentMethod', 
                                       TotalAmount = '$updatedTotalAmount', 
                                       PaymentStatus = '$updatedPaymentStatus', 
                                       DatePaid = '$updatedDatePaid'
                                   WHERE ReservationID = $reservationID";

            $updatePaymentResult = mysqli_query($connection, $updatePaymentQuery);

            if ($updateReservationResult !== false && $updateGuestResult !== false && $updatePaymentResult !== false) {
                $_SESSION['message'] = 'Booking details updated successfully.';
                header('Location: index.php?reservation ReservationID=' . $reservationID);
                exit();
            } else {
                $_SESSION['error'] = 'Error updating booking details: ' . mysqli_error($connection);
            }
        }
    } else {
        $_SESSION['error'] = 'Booking not found.';
        header('Location: index.php?reservation');
        exit();
    }
} else {
    $_SESSION['error'] = 'Invalid ReservationID.';
    header('Location: index.php?reservation');
    exit();
}
?>
<!-- The rest of your HTML code with input fields for reservation, guest, and payment details -->

<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Update Booking</title>
</head>

<body>

    <div class="container mt-4">
        <?php include('message.php'); ?>

        <div class="row mb-3">
            <div class="col-md-12">
                <a href="index.php? reservation" class="btn btn-primary">Back to View</a>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Update Booking</h4>
                    </div>
                    <div class="card-body">
                        <form action="updatereservation.php?ReservationID=<?= $reservationID; ?>" method="POST">
                            <!-- Add input fields for the updated information -->
                            <div class="mb-3">
                                <label for="updatedCheckInDate" class="form-label">Updated Check-in Date</label>
                                <input type="date" class="form-control" id="updatedCheckInDate" name="updatedCheckInDate" value="<?= $bookingDetails['CheckInDate']; ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="updatedCheckOutDate" class="form-label">Updated Check-out Date</label>
                                <input type="date" class="form-control" id="updatedCheckOutDate" name="updatedCheckOutDate" value="<?= $bookingDetails['CheckOutDate']; ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="updatedRoomNumber" class="form-label">Updated Room Number</label>
                                <input type="text" class="form-control" id="updatedRoomNumber" name="updatedRoomNumber" value="<?= $bookingDetails['RoomNumber']; ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="updatedNumberOfAdults" class="form-label">Updated Number of Adults</label>
                                <input type="number" class="form-control" id="updatedNumberOfAdults" name="updatedNumberOfAdults" value="<?= $bookingDetails['NumberOfAdults']; ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="updatedNumberOfChildren" class="form-label">Updated Number of Children</label>
                                <input type="number" class="form-control" id="updatedNumberOfChildren" name="updatedNumberOfChildren" value="<?= $bookingDetails['NumberOfChildren']; ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="updatedFirstName" class="form-label">Updated First Name</label>
                                <input type="text" class="form-control" id="updatedFirstName" name="updatedFirstName" value="<?= $bookingDetails['FirstName']; ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="updatedLastName" class="form-label">Updated Last Name</label>
                                <input type="text" class="form-control" id="updatedLastName" name="updatedLastName" value="<?= $bookingDetails['LastName']; ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="updatedEmail" class="form-label">Updated Email</label>
                                <input type="email" class="form-control" id="updatedEmail" name="updatedEmail" value="<?= $bookingDetails['Email']; ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="updatedPhone" class="form-label">Updated Phone</label>
                                <input type="text" class="form-control" id="updatedPhone" name="updatedPhone" value="<?= $bookingDetails['Phone']; ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="updatedAddress" class="form-label">Updated Address</label>
                                <input type="text" class="form-control" id="updatedAddress" name="updatedAddress" value="<?= $bookingDetails['Address']; ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="updatedReservationID" class="form-label">Updated Reservation ID</label>
                                <input type="text" class="form-control" id="updatedReservationID" name="updatedReservationID" value="<?= $bookingDetails['ReservationID']; ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="updatedPaymentID" class="form-label">Updated Payment ID</label>
                                <input type="text" class="form-control" id="updatedPaymentID" name="updatedPaymentID" value="<?= $bookingDetails['PaymentID']; ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="updatedTotalAmount" class="form-label">Updated Total Amount</label>
                                <input type="text" class="form-control" id="updatedTotalAmount" name="updatedTotalAmount" value="<?= $bookingDetails['TotalAmount']; ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="updatedPaymentMethod" class="form-label">Updated Payment Method</label>
                                <input type="text" class="form-control" id="updatedPaymentMethod" name="updatedPaymentMethod" value="<?= $bookingDetails['PaymentMethod']; ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="updatedPaymentStatus" class="form-label">Updated Payment Status</label>
                                <input type="text" class="form-control" id="updatedPaymentStatus" name="updatedPaymentStatus" value="<?= $bookingDetails['PaymentStatus']; ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="updatedDatePaid" class="form-label">Updated Date Paid</label>
                                <input type="date" class="form-control" id="updatedDatePaid" name="updatedDatePaid" value="<?= $bookingDetails['DatePaid']; ?>" required>
                            </div>
                            <!-- Add more input fields for other updated information -->

                            <button type="submit" name="update_booking" class="btn btn-primary">Update Booking</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>
