<a href="index.php?billing" class="btn btn-primary">Back to View</a>
<?php
require 'db.php'; // Assuming your database connection file is named 'db.php'

// Function to fetch data from a table and return it as an associative array
function fetchDropdownData($connection, $tableName, $idColumn, $nameColumn) {
    $query = "SELECT $idColumn, $nameColumn FROM $tableName";
    $result = mysqli_query($connection, $query);
    $data = array();

    while ($row = mysqli_fetch_assoc($result)) {
        $data[] = $row;
    }

    return $data;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Fetch data from the form for billing details
    $billID = $_POST['billID'];
    $reservationID = $_POST['reservationID'];
    $guestID = $_POST['guestID'];
    $totalAmount = $_POST['totalAmount'];
    $taxAmount = $_POST['taxAmount'];
    $discountAmount = $_POST['discountAmount'];

    // Insert data into billingdetails table
    $insertBillingQuery = "INSERT INTO billingdetails (BillID, ReservationID, GuestID, TotalAmount, TaxAmount, DiscountAmount) 
                           VALUES ('$billID', '$reservationID', '$guestID', '$totalAmount', '$taxAmount', '$discountAmount')";

    if (mysqli_query($connection, $insertBillingQuery)) {
        // Redirect to billing.php with a success message
        header("Location: index.php?billing");
        exit();
    } else {
        // Redirect to billing.php with an error message
        header("Location: billing.php?error=Error adding billing details: " . mysqli_error($connection));
        exit();
    }
}

// Fetch data for dropdowns
$guests = fetchDropdownData($connection, 'guestdetails', 'GuestID', 'FirstName');
$reservations = fetchDropdownData($connection, 'reservationdetails', 'ReservationID', 'ReservationID');
$paymentData = fetchDropdownData($connection, 'paymentdetails', 'PaymentID', 'TotalAmount');
?>

<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Add Billing Details</title>
</head>
<body>
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-6 offset-md-3">
                <div class="card">
                    <div class="card-header">
                    
                        <h4>Add Billing Details</h4>
                    </div>
                    <div class="card-body">
                        <!-- Display success or error messages if any -->
                        <?php
                        if (isset($_GET['success'])) {
                            echo '<div class="alert alert-success">' . $_GET['success'] . '</div>';
                        } elseif (isset($_GET['error'])) {
                            echo '<div class="alert alert-danger">' . $_GET['error'] . '</div>';
                        }
                        ?>

                        <!-- Billing Details Form -->
                        
                        <form method="POST" action="">
                            <div class="mb-3">
                                <label for="billID" class="form-label">Bill ID</label>
                                <input type="text" class="form-control" name="billID" required>
                            </div>
                            <div class="mb-3">
                                <label for="reservationID" class="form-label">Reservation ID</label>
                                <select class="form-select" name="reservationID" required>
                                    <?php foreach ($reservations as $reservation): ?>
                                        <option value="<?= $reservation['ReservationID']; ?>"><?= $reservation['ReservationID']; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="guestID" class="form-label">Guest ID</label>
                                <select class="form-select" name="guestID" required>
                                    <?php foreach ($guests as $guest): ?>
                                        <option value="<?= $guest['GuestID']; ?>"><?= $guest['FirstName']; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="totalAmount" class="form-label">Total Amount</label>
                                <select class="form-select" name="totalAmount" required>
                                    <?php foreach ($paymentData as $payment): ?>
                                        <option value="<?= $payment['TotalAmount']; ?>"><?= $payment['TotalAmount']; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="taxAmount" class="form-label">Tax Amount</label>
                                <input type="text" class="form-control" name="taxAmount" required>
                            </div>
                            <div class="mb-3">
                                <label for="discountAmount" class="form-label">Discount Amount</label>
                                <input type="text" class="form-control" name="discountAmount" required>
                            </div>
                          <a href="index.php? billing">  <button type="submit" class="btn btn-primary">Add Billing Details</button></a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
