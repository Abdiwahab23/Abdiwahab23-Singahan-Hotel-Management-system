<a href="index.php?staff_mang" class="btn btn-primary">Back to View</a>
<?php
require 'db.php'; // Assuming your database connection file is named 'db.php'

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    // Check if the EmployeeID is set in the URL
    if (isset($_GET['EmployeeID'])) {
        $employeeID = $_GET['EmployeeID'];

        // Delete from employeeshift table first
        $deleteShiftQuery = "DELETE FROM employeeshift WHERE EmployeeID = $employeeID";

        if (mysqli_query($connection, $deleteShiftQuery)) {
            // After deleting from employeeshift, delete from employeedetails table
            $deleteEmployeeQuery = "DELETE FROM employeedetails WHERE EmployeeID = $employeeID";

            if (mysqli_query($connection, $deleteEmployeeQuery)) {
                // Redirect to staff_mang.php with a success message
                header("Location: index.php?staff_mang");
                exit();
            } else {
                // Redirect to staff_mang.php with an error message
                header("Location: index.php?staff_mang?error=Error deleting staff member: " . mysqli_error($connection));
                exit();
            }
        } else {
            // Redirect to staff_mang.php with an error message
            header("Location: index.php?staff_mang?error=Error deleting shifts: " . mysqli_error($connection));
            exit();
        }
    } else {
        // Redirect to staff_mang.php with an error message if EmployeeID is not set
        header("Location: index.php?staff_mang ?error=EmployeeID not specified");
        exit();
    }
} else {
    // Redirect to staff_mang.php with an error message for invalid request method
    header("Location: index.php?staff_mang?error=Invalid request method");
    exit();
}
?>
