<?php
require 'db.php'; // Assuming your database connection file is named 'db.php'
?>

<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Billing Details</title>
    <style>
        body{
            margin:0;
            padding:0;
        }
        .col-md-12{
            margin-left:100px;
            margin-top:-550px;
        }
        .row{
            max-width:1230px;
        }
        .row-names{
            font-size:14px;
        }

        
    </style>
</head>
<body>
    
  

    <div class="container mt-4">
        <?php include('message.php'); ?>

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Billing Details
                            <a href="Addbilling.php" class="btn btn-primary float-end">Add Billing</a>
                        </h4>
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr class="row-names">
                                    <th>Bill ID</th>
                                    <th>Reservation ID</th>
                                    <th>Guest ID</th>
                                    <th>Total Amount</th>
                                    <th>Tax Amount</th>
                                    <th>Discount Amount</th>
                                    <th>Action</th>
                                </tr>
                            </thead>

                            <?php
                            $billingQuery = "SELECT * FROM billingdetails";
                            $billingResult = mysqli_query($connection, $billingQuery);

                            if (mysqli_num_rows($billingResult) > 0) {
                                foreach ($billingResult as $row) {
                                    ?>
                                    <tr>
                                        <td><?= $row['BillID']; ?></td>
                                        <td><?= $row['ReservationID']; ?></td>
                                        <td><?= $row['GuestID']; ?></td>
                                        <td><?= $row['TotalAmount']; ?></td>
                                        <td><?= $row['TaxAmount']; ?></td>
                                        <td><?= $row['DiscountAmount']; ?></td>
                                        <td>
                                            <!-- Add your actions here, e.g., update and delete links or buttons -->
                                            <a href="updatebilling.php?BillID=<?= $row['BillID']; ?>" class="btn btn-primary btn-sm">Update</a>
                                            <a href="deletebilling.php?BillID=<?= $row['BillID']; ?>" class="btn btn-danger btn-sm">Delete</a>
                                            <form action="deletebilling.php" method="POST" class="d-inline">
                                                <input type="hidden" name="BillID" value="<?= $row['BillID']; ?>">
                                                <!-- Add any additional hidden inputs if needed -->
                                               
                                            </form>
                                        </td>
                                    </tr>
                                    <?php
                                }
                            } else {
                                echo "<tr><td colspan='7'>No billing data available</td></tr>";
                            }
                            ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
