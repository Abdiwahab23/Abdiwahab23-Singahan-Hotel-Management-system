<?php
    
    require 'db.php'; // Assuming your database connection file is named 'db.php'
?>

<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Room Data</title>
    <style>
        body{
            margin:0;
            padding:0;
        }
        .col-md-12{
            margin-left: -23px;
            margin-top:-560px;
        }
        .row{
            max-width:1240px;
        }
        .row-names{
            font-size:12px;
        }

        
    </style>
</head>
<body>
    <style>
        .container{

            margin-left:220px;
        }
    </style>

<div class="container mt-4">
    <?php include('message.php'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4>Room Data
                        <a href="Addroom.php" class="btn btn-primary float-end">Add Room</a>
                    </h4>
                </div>
                <div class="card-body">
                    <table class="table table-bordered table-striped">
                        <thead>
                        <tr class="row-names">
                            <th>Room Number</th>
                            <th>Room Type</th>
                            <th>Price Per Night</th>
                            <th>Occupancy ID</th>
                            <th>Guest ID</th>
                            <th>Check-in Date</th>
                            <th>Check-out Date</th>
                            <th>Status ID</th>
                            <th>Date</th>
                            <th>Room Status</th>
                            <!-- Add more columns based on your database -->
                            <th>Action</th>
                        </tr>
                        </thead>
                        
                        <?php
                        $roomQuery = "SELECT rd.RoomNumber, rd.RoomType, rd.PricePerNight,
                                      ro.OccupancyID, ro.GuestID, ro.CheckInDate, ro.CheckOutDate,
                                      rs.StatusID, rs.Date, rs.Status AS RoomStatus
                                      FROM roomdetails rd
                                      LEFT JOIN roomoccupancy ro ON rd.RoomNumber = ro.RoomNumber
                                      LEFT JOIN roomstatus rs ON rd.RoomNumber = rs.RoomNumber";

                        $roomResult = mysqli_query($connection, $roomQuery);

                        if (mysqli_num_rows($roomResult) > 0) {
                            foreach ($roomResult as $row) {
                                ?>
                                <tr>
                                    <td><?= $row['RoomNumber']; ?></td>
                                    <td><?= $row['RoomType']; ?></td>
                                    <td><?= $row['PricePerNight']; ?></td>
                                    <td><?= $row['OccupancyID']; ?></td>
                                    <td><?= $row['GuestID']; ?></td>
                                    <td><?= $row['CheckInDate']; ?></td>
                                    <td><?= $row['CheckOutDate']; ?></td>
                                    <td><?= $row['StatusID']; ?></td>
                                    <td><?= $row['Date']; ?></td>
                                    <td><?= $row['RoomStatus']; ?></td>
                                    <!-- Add more columns based on your database -->
                                    <td>
                                        <!-- Add your actions here, e.g., update and delete links or buttons -->
                                        <a href="updateroom.php?RoomNumber=<?= $row['RoomNumber']; ?>" class="btn btn-primary btn-sm">Update</a>
                                        <a href="deleteroom.php?RoomNumber=<?= $row['RoomNumber']; ?>" class="btn btn-danger btn-sm">Delete</a>
                                        <form action="delete.php" method="POST" class="d-inline">
                                            <input type="hidden" name="RoomNumber" value="<?= $row['RoomNumber']; ?>">
                                        </form>
                                    </td>
                                </tr>
                                <?php
                            }
                        } else {
                            echo "<tr><td colspan='11'>No room data available</td></tr>";
                        }
                        ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>