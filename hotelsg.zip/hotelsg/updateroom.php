<?php
session_start();

// Include your database connection file
require 'db.php';

// Check if the room number is set in the URL
if (isset($_GET['RoomNumber'])) {
    // Get the room number from the URL
    $roomNumber = $_GET['RoomNumber'];

    // Fetch the existing room details from the database
    $roomQuery = "SELECT rd.*, ro.OccupancyID, ro.GuestID, ro.CheckInDate AS OccupancyCheckInDate, ro.CheckOutDate AS OccupancyCheckOutDate, rs.StatusID, rs.Date AS StatusDate, rs.Status AS RoomStatus
                  FROM roomdetails rd
                  LEFT JOIN roomoccupancy ro ON rd.RoomNumber = ro.RoomNumber
                  LEFT JOIN roomstatus rs ON rd.RoomNumber = rs.RoomNumber
                  WHERE rd.RoomNumber = $roomNumber";

    $result = mysqli_query($connection, $roomQuery);

    if ($result && mysqli_num_rows($result) > 0) {
        $roomDetails = mysqli_fetch_assoc($result);

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_room'])) {
            // Collect updated data from the form
            $updatedRoomType = $_POST['updatedRoomType'] ?? $roomDetails['RoomType'];
            $updatedPricePerNight = $_POST['updatedPricePerNight'] ?? $roomDetails['PricePerNight'];
            $updatedOccupancyID = $_POST['updatedOccupancyID'] ?? $roomDetails['OccupancyID'];
            $updatedGuestID = $_POST['updatedGuestID'] ?? $roomDetails['GuestID'];
            $updatedOccupancyCheckInDate = $_POST['updatedOccupancyCheckInDate'] ?? $roomDetails['OccupancyCheckInDate'];
            $updatedOccupancyCheckOutDate = $_POST['updatedOccupancyCheckOutDate'] ?? $roomDetails['OccupancyCheckOutDate'];
            $updatedStatusID = $_POST['updatedStatusID'] ?? $roomDetails['StatusID'];
            $updatedStatusDate = $_POST['updatedStatusDate'] ?? $roomDetails['StatusDate'];
            $updatedRoomStatus = $_POST['updatedRoomStatus'] ?? $roomDetails['RoomStatus'];
            $updatedRoomNumber = $_POST['updatedRoomNumber'] ?? $roomNumber; // Add this line

            // Perform the update in the roomdetails table
            $updateRoomQuery = "UPDATE roomdetails 
                                SET 
                                    RoomType = '$updatedRoomType',  
                                    PricePerNight = '$updatedPricePerNight'
                                WHERE RoomNumber = $updatedRoomNumber"; // Use $updatedRoomNumber here

            $updateRoomResult = mysqli_query($connection, $updateRoomQuery);

            // Perform the update in the roomoccupancy table
            $updateOccupancyQuery = "UPDATE roomoccupancy 
                                     SET 
                                         GuestID = '$updatedGuestID', 
                                         CheckInDate = '$updatedOccupancyCheckInDate', 
                                         CheckOutDate = '$updatedOccupancyCheckOutDate'
                                     WHERE OccupancyID = $updatedOccupancyID";

            $updateOccupancyResult = mysqli_query($connection, $updateOccupancyQuery);

            // Perform the update in the roomstatus table
            $updateStatusQuery = "UPDATE roomstatus 
                                  SET 
                                    
                                      Date = '$updatedStatusDate', 
                                      Status = '$updatedRoomStatus'
                                  WHERE StatusID = $updatedStatusID";

            $updateStatusResult = mysqli_query($connection, $updateStatusQuery);

            if ($updateRoomResult !== false && $updateOccupancyResult !== false && $updateStatusResult !== false) {
                $_SESSION['message'] = 'Room details updated successfully.';
                header('Location: index.php?room_mang RoomNumber=' . $updatedRoomNumber);
                exit();
            } else {
                $_SESSION['error'] = 'Error updating room details: ' . mysqli_error($connection);
            }
        }
    } else {
        $_SESSION['error'] = 'Room not found.';
        header('Location: index.php?room_mang');
        exit();
    }
} else {
    $_SESSION['error'] = 'Invalid RoomNumber.';
    header('Location: index.php?room_mang');
    exit();
}

// Fetch GuestID values from guestdetails table
$guestQuery = "SELECT GuestID, FirstName, LastName FROM guestdetails";
$guestResult = mysqli_query($connection, $guestQuery);
$guestOptions = '';
while ($guest = mysqli_fetch_assoc($guestResult)) {
    $selected = ($guest['GuestID'] == $roomDetails['GuestID']) ? 'selected' : '';
    $guestOptions .= "<option value='{$guest['GuestID']}' $selected>{$guest['FirstName']}</option>";
}

// Fetch RoomNumber values from reservationdetails table
$roomQuery = "SELECT RoomNumber FROM reservationdetails";
$roomResult = mysqli_query($connection, $roomQuery);
$roomOptions = '';
while ($room = mysqli_fetch_assoc($roomResult)) {
    $selected = ($room['RoomNumber'] == $roomNumber) ? 'selected' : '';
    $roomOptions .= "<option value='{$room['RoomNumber']}' $selected>{$room['RoomNumber']}</option>";
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Update Room</title>
</head>

<body>

    <div class="container mt-4">
        <?php include('message.php'); ?>

        <div class="row mb-3">
            <div class="col-md-12">
                <a href="index.php?room_mang" class="btn btn-primary">Back to View</a>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Update Room</h4>
                    </div>
                    <div class="card-body">
                        <form action="updateroom.php?RoomNumber=<?= $roomNumber; ?>" method="POST">
                            <!-- Add input fields for the updated information -->
                            <div class="mb-3">
                                <label for="updatedRoomType" class="form-label">Updated Room Type</label>
                                <input type="text" class="form-control" id="updatedRoomType" name="updatedRoomType" value="<?= $roomDetails['RoomType']; ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="updatedPricePerNight" class="form-label">Updated Price Per Night</label>
                                <input type="text" class="form-control" id="updatedPricePerNight" name="updatedPricePerNight" value="<?= $roomDetails['PricePerNight']; ?>" required>
                            </div>
                            
                                <label for="updatedGuestID" class="form-label">Updated Guest ID</label>
                                <select class="form-control" id="updatedGuestID" name="updatedGuestID" required>
                                    <?php echo $guestOptions; ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="updatedOccupancyCheckInDate" class="form-label">Updated Occupancy Check-in Date</label>
                                <input type="date" class="form-control" id="updatedOccupancyCheckInDate" name="updatedOccupancyCheckInDate" value="<?= $roomDetails['OccupancyCheckInDate']; ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="updatedOccupancyCheckOutDate" class="form-label">Updated Occupancy Check-out Date</label>
                                <input type="date" class="form-control" id="updatedOccupancyCheckOutDate" name="updatedOccupancyCheckOutDate" value="<?= $roomDetails['OccupancyCheckOutDate']; ?>" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="updatedStatusDate" class="form-label">Updated Status Date</label>
                                <input type="date" class="form-control" id="updatedStatusDate" name="updatedStatusDate" value="<?= $roomDetails['StatusDate']; ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="updatedRoomStatus" class="form-label">Updated Room Status</label>
                                <input type="text" class="form-control" id="updatedRoomStatus" name="updatedRoomStatus" value="<?= $roomDetails['RoomStatus']; ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="updatedRoomNumber" class="form-label">Updated Room Number</label>
                                <select class="form-control" id="updatedRoomNumber" name="updatedRoomNumber" required>
                                    <?php echo $roomOptions; ?>
                                </select>
                            </div>
                            <!-- Add more input fields for other updated information -->

                            <button type="submit" name="update_room" class="btn btn-primary">Update Room</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>
